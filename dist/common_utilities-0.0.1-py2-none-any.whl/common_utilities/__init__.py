def my_function():
    print("common method v1")


