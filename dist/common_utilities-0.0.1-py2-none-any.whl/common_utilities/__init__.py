def my_function():
    print("common method")


